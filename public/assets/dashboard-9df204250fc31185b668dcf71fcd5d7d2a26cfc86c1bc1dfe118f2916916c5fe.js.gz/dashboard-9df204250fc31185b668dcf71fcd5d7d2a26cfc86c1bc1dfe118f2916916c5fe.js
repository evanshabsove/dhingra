$(function(){

  // $(document).on('click','#create_painting_button', {}, function(){
  //   event.preventDefault();
  //   var parent = $(this).parent()
  //   var id = parent.attr("id")
  //   $.ajax({
  //     url: "/galleries/" + id + "/paintings",
  //     method: "post",
  //     dataType: "JSON",
  //     data: $("#new_painting").serialize()
  //   }).done(function(responseData){
  //     $("#all-paintings").html(responseData.html)
  //   });
  // });

  // TODO: Have learned that image uploading does not work in ajax requests with carrier wave. so removing ajax.
});

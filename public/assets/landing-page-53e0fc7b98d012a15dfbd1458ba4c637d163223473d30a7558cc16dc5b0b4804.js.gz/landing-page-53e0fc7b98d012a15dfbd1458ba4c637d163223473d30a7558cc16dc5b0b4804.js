$(function(){  $(".opening-title").fadeIn(1000, function() {
    $(".home-page-link").fadeIn(500)
  })
  console.log("loaded");
});
